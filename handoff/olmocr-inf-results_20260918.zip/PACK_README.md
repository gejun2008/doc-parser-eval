# olmOCR-Bench · INF 结果包

生成时间: 2026-09-29T09:59:42Z
来源仓库: gejun2008/doc-parser-eval @ 8857323

## 内容
- `runs/inf-mllm_doc2md_20260918T065831Z/`  INF (inf-mllm, doc2md) 在 120 页抽样子集上的 run
  - raw/*.json          每次调用的原始响应（120 份）
  - olmocr_results.csv  逐条测试 pass/fail（604 条）——配对比较要用这个
  - olmocr_summary.json 分层汇总
  - run_meta.json       调用参数（含厂商端点 URL，不含 API key）
- `data/olmocr_bench/`  抽样子集：manifest.csv、subset_meta.json、官方测试 jsonl、120 个 PDF

## 使用
在 inf-eval 仓库根目录解压，路径即对位：

    unzip olmocr-inf-results_20260918.zip -d <inf-eval 根目录>

然后跑 Azure DI 并打分、配对比较：

    python tools/azure_di_runner.py --dry-run   # 先核对清单
    python tools/azure_di_runner.py ...         # olmOCR-Bench 清单
    python tools/score_olmocr.py runs/azure_di_layout_<ts>
    python tools/compare_systems.py runs/inf-mllm_doc2md_20260918T065831Z/olmocr_results.csv runs/azure_di_layout_<ts>/olmocr_results.csv

判定器必须用仓库内 tools/vendor/olmocr（commit ab294c6a），不要换官方最新版。
