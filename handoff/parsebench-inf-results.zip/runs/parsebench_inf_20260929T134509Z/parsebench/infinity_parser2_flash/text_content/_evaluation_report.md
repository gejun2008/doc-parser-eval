# Evaluation Report

**Generated:** 2026-09-30T01:23:32.096059

## Summary

- **Total Examples:** 150
- **Successful:** 150
- **Failed:** 0
- **Skipped:** 0

## Latency Ms Statistics

- **Average:** 230096.2ms
- **Total:** 34514431ms
- **Min:** 6879.0ms
- **Max:** 1434623.0ms
- **P50:** 154684.0ms
- **P95:** 696303.0ms
- **P99:** 1044670.0ms
- **Count:** 150

## Aggregate Metrics

| Metric | Value |
|--------|-------|
| Content Faithfulness | 0.8671 |
| Normalized Order | 0.8301 |
| Normalized Text Correctness | 0.8847 |
| Normalized Text Score | 0.8583 |
| Rule Bag Of Digit Percent Pass Rate | 0.9457 |
| Rule Is Footer Pass Rate | 0.3140 |
| Rule Is Header Pass Rate | 0.2637 |
| Rule Missing Sentence Percent Pass Rate | 0.7148 |
| Rule Missing Specific Sentence Pass Rate | 0.7141 |
| Rule Missing Specific Word Pass Rate | 0.9420 |
| Rule Missing Word Percent Pass Rate | 0.9355 |
| Rule Order Pass Rate | 0.8301 |
| Rule Pass Rate | 0.8886 |
| Rule Too Many Sentence Occurence Percent Pass Rate | 0.9464 |
| Rule Too Many Word Occurence Percent Pass Rate | 0.9716 |
| Rule Unexpected Sentence Percent Pass Rate | 0.7601 |
| Rule Unexpected Word Percent Pass Rate | 0.9155 |
