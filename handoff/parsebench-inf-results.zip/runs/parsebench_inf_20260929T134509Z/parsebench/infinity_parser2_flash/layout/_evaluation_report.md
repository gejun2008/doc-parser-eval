# Evaluation Report

**Generated:** 2026-09-30T01:23:06.391427

## Summary

- **Total Examples:** 120
- **Successful:** 120
- **Failed:** 0
- **Skipped:** 0

## Latency Ms Statistics

- **Average:** 239124.7ms
- **Total:** 28694966ms
- **Min:** 11659.0ms
- **Max:** 1097556.0ms
- **P50:** 181131.0ms
- **P95:** 657902.0ms
- **P99:** 892236.0ms
- **Count:** 120

## Aggregate Metrics

| Metric | Value |
|--------|-------|
| Ap50 | 0.6980 |
| Ap75 | 0.5388 |
| Af1 | 0.9044 |
| Content Faithfulness | 0.9125 |
| F1 Page-Footer | 0.6052 |
| F1 Page-Header | 0.3696 |
| F1 Picture | 0.8001 |
| F1 Section | 0.7354 |
| F1 Table | 0.7432 |
| F1 Text | 0.7566 |
| Lap | 0.9827 |
| Lar | 0.8848 |
| Layout Attribution Pass Rate | 0.8252 |
| Layout Classification Pass Rate | 0.8022 |
| Layout Element Rule Pass Rate | 0.7540 |
| Layout Localization Pass Rate | 0.8565 |
| Layout Reading Order Pass Rate | 0.8833 |
| Layout Rule Pass Rate | 0.8289 |
| Map@[.50:.95] | 0.5070 |
| Mean F1 | 0.6838 |
| Normalized Order | 0.9125 |
| Normalized Text Score | 0.9125 |
| Num Ground Truth | 28.1083 |
| Num Predictions | 30.9250 |
| Precision Page-Footer | 0.5651 |
| Precision Page-Header | 0.3656 |
| Precision Picture | 0.8348 |
| Precision Section | 0.7900 |
| Precision Table | 0.7703 |
| Precision Text | 0.7609 |
| Recall Page-Footer | 0.6941 |
| Recall Page-Header | 0.3995 |
| Recall Picture | 0.7908 |
| Recall Section | 0.7723 |
| Recall Table | 0.7387 |
| Recall Text | 0.7844 |
| Rule Order Pass Rate | 0.9125 |
| Rule Pass Rate | 0.8393 |
| Unmatched Gt Elements | 2.9500 |
| Unmatched Pred Elements | 4.9250 |
