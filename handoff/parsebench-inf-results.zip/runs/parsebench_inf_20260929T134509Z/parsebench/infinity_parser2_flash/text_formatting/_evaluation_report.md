# Evaluation Report

**Generated:** 2026-09-30T01:23:35.760827

## Summary

- **Total Examples:** 138
- **Successful:** 138
- **Failed:** 0
- **Skipped:** 12

## Latency Ms Statistics

- **Average:** 234006.1ms
- **Total:** 32292844ms
- **Min:** 6879.0ms
- **Max:** 1434623.0ms
- **P50:** 154684.0ms
- **P95:** 714223.0ms
- **P99:** 1044670.0ms
- **Count:** 138

## Aggregate Metrics

| Metric | Value |
|--------|-------|
| Normalized Code Block | 0.0000 |
| Normalized Latex | 0.1778 |
| Normalized Text Score | 0.4653 |
| Normalized Text Styling | 0.3116 |
| Normalized Title Accuracy | 0.5809 |
| Rule Is Bold Pass Rate | 0.2310 |
| Rule Is Code Block Pass Rate | 0.0000 |
| Rule Is Italic Pass Rate | 0.0263 |
| Rule Is Latex Pass Rate | 0.1778 |
| Rule Is Mark Pass Rate | 0.0000 |
| Rule Is Strikeout Pass Rate | 0.0000 |
| Rule Is Sub Pass Rate | 0.2500 |
| Rule Is Sup Pass Rate | 0.1339 |
| Rule Is Title Pass Rate | 0.6314 |
| Rule Is Underline Pass Rate | 0.0000 |
| Rule Pass Rate | 0.3681 |
| Rule Title Hierarchy Percent Pass Rate | 0.5305 |
| Semantic Formatting | 0.4653 |
