# Evaluation Report

**Generated:** 2026-09-30T01:23:18.483295

## Summary

- **Total Examples:** 130
- **Successful:** 130
- **Failed:** 0
- **Skipped:** 0

## Latency Ms Statistics

- **Average:** 142448.0ms
- **Total:** 18518236ms
- **Min:** 9385.0ms
- **Max:** 621372.0ms
- **P50:** 110989.0ms
- **P95:** 350828.0ms
- **P99:** 489896.0ms
- **Count:** 130

## Aggregate Metrics

| Metric | Value |
|--------|-------|
| GriTS Con (All) | 0.8669 |
| GriTS Con (Among Predicted Tables) | 0.9015 |
| Grits Trm Composite | 0.7484 |
| Structural Consistency | 0.6885 |
| Table Record Match | 0.6223 |
| Table Record Match Perfect | 0.3660 |
| Table Record Match Perfect Predicted | 0.3807 |
| Table Record Match Predicted | 0.6472 |
| Tables Actual | 1.6000 |
| Tables Expected | 1.5680 |
| Tables Paired | 1.5120 |
| Tables Unmatched Expected | 0.0560 |
| Tables Unmatched Pred | 0.0880 |
| Tables Unparseable Pred | 0.0000 |
