# Evaluation Report

**Generated:** 2026-09-30T01:23:01.943970

## Summary

- **Total Examples:** 100
- **Successful:** 100
- **Failed:** 0
- **Skipped:** 0

## Latency Ms Statistics

- **Average:** 175677.5ms
- **Total:** 17567746ms
- **Min:** 36009.0ms
- **Max:** 1038533.0ms
- **P50:** 130501.0ms
- **P95:** 490889.0ms
- **P99:** 1038533.0ms
- **Count:** 100

## Aggregate Metrics

| Metric | Value |
|--------|-------|
| Rule Chart Data Point Pass Rate | 0.5826 |
| Rule Pass Rate | 0.5826 |
