# 交接包 · Infinity-Parser2 评测

生成于 2026-09-23T03:54:05+00:00　提交 d67fbf0

## 这个包里有什么

| 内容 | 说明 |
|---|---|
| `runs/` | 每次评测的逐页原始响应与逐条判定，报告附录的复现依据 |
| `probe_out/` | T0 端点探针证据 |
| `corpus_manifest/` | 语料与选页清单（含 source_url 与 sha256） |
| `data/` | 未包含语料 PDF，需在公司电脑按 manifest 重新下载 |

**不含** `.env` 与任何凭证。公司电脑上需自行填 Azure 凭证。

## 一、取得仓库

本包不含仓库快照。代码与文档从仓库获取：

```bash
git clone https://github.com/gejun2008/doc-parser-eval.git inf-eval
```

## 二、建环境

```bash
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -r requirements.txt
```

判定与扰动组还需要额外依赖（olmOCR 官方评分模块已 vendor 在 `tools/vendor/olmocr`）：

```bash
uv pip install --python .venv/bin/python -r requirements-scoring.txt
.venv/bin/python -m playwright install chromium     # math 类断言要 KaTeX 渲染
```

若公司网络装不了 playwright，判定时加 `--skip-math`，math 类记为未评。

## 三、放回评测产物

```bash
cp -R runs probe_out inf-eval/
cp corpus_manifest/*.csv corpus_manifest/*.json inf-eval/data/corpus/
# 未带语料，在公司电脑重新下载：
# .venv/bin/python tools/fetch_olmocr_bench.py
# .venv/bin/python tools/fetch_corpus.py --per-family 4
# .venv/bin/python tools/select_pages.py
```

## 四、填 Azure 凭证

```bash
cd inf-eval && cp .env.example .env
```

只填这两项：

```
AZURE_DI_ENDPOINT=https://<资源名>.cognitiveservices.azure.com
AZURE_DI_KEY=<key>
```

凭证只进 `.env`，`.env` 已在 `.gitignore` 中。**不要填进 `.env.example`**。

## 五、预检（不花钱）

```bash
.venv/bin/python tools/azure_di_runner.py --dry-run \
    --pages-csv data/corpus/pages.csv
.venv/bin/python tools/azure_di_runner.py --dry-run \
    --pages-csv data/olmocr_bench/manifest.csv \
    --pdf-root data/olmocr_bench/bench_data/pdfs
```

## 六、跑基线

```bash
set -a && source .env && set +a

# 第三层 自建金融场景集 210 页，约 $2.10
.venv/bin/python tools/azure_di_runner.py --concurrency 4 \
    --pages-csv data/corpus/pages.csv
.venv/bin/python tools/check.py runs/azure_di_layout_<时间戳>

# 第二层 olmOCR-Bench 120 页，约 $1.20
.venv/bin/python tools/azure_di_runner.py --concurrency 4 \
    --pages-csv data/olmocr_bench/manifest.csv \
    --pdf-root data/olmocr_bench/bench_data/pdfs
.venv/bin/python tools/score_olmocr.py runs/azure_di_layout_<时间戳>
```

中断了就加 `--resume runs/azure_di_layout_<时间戳>`，已成功的页会跳过。

## 七、比对

Infinity-Parser2 的对应结果已在包里，两边跑的是同一批页、同一套断言、同一个判定器：

| 层 | Infinity-Parser2 run_id |
|---|---|
| 第二层 olmOCR-Bench | `inf-mllm_doc2md_20260918T065831Z` |
| 第三层 自建集 | `inf-mllm_doc2md_20260921T013924Z` |

```bash
# 第三层
.venv/bin/python tools/compare_systems.py \
    runs/inf-mllm_doc2md_20260921T013924Z/results.csv \
    runs/azure_di_layout_<时间戳>/results.csv \
    --name-a Infinity --name-b AzureDI

# 第二层
.venv/bin/python tools/compare_systems.py \
    runs/inf-mllm_doc2md_20260918T065831Z/olmocr_results.csv \
    runs/azure_di_layout_<时间戳>/olmocr_results.csv \
    --name-a Infinity --name-b AzureDI
```

### 读这张表的三条纪律

两边判的是**同一批断言**，属配对数据，所以用 McNemar 检验而不是比两个置信区间。
表里的 `b/c` 是「只有 A 对」与「只有 B 对」的条数，差异是否显著看它们。

1. **「全部」那一行不是加权总分**，只是同口径汇总。结论按分层写
2. **p ≥ 0.05 写「未观察到显著差异」**，不得写成「持平」「相当」「不相上下」
3. **n < 30 的分层写「样本不足，不下结论」**，不要为了好看合并分层

### 写进报告时必须声明的不对称

- Azure DI 按整份文档分析，即使指定单页也可能利用全文上下文，
  Infinity-Parser2 是逐页独立调用。**这一条对 Azure 有利，要主动写明**
- 两边 markdown 风格由各自厂商决定，`formatting` 类断言不可跨系统比较
- Azure 返回 span 级 confidence，Infinity-Parser2 没有，置信度只能单边报
- 选页刻意偏向财务报表页，两边同批页，但绝对分数天然低于通用文档

完整清单见 `docs/azure-di-baseline.md`。

## 注意

- Azure DI 按整份文档分析，即使指定 `pages=N` 也可能用到全文上下文，
  **这一点对 Azure 有利，报告里要主动写明**（见 `docs/azure-di-baseline.md`）
- 转换由微软做（`outputContentFormat=markdown`），我们不碰转换规则，
  落盘记录里 `"conversion_by_us": false` 是证据
- 若语料是在公司电脑重新下载的，**核对 `manifest.csv` 里的 sha256**。
  对不上说明源站文件有更新，两边跑的不是同一份文档，结果不可比
